import{_ as e,c,o}from"./index-DU-VOt6M.js";const t={};function n(a,r){return o(),c("h1",null,"This is an about page")}const _=e(t,[["render",n]]);export{_ as default};
