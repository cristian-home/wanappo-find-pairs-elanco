import{_ as e,c as o,o as c}from"./index-DU-VOt6M.js";const n={};function t(r,_){return c(),o("h1",null,"Page Not Found")}const s=e(n,[["render",t]]);export{s as default};
