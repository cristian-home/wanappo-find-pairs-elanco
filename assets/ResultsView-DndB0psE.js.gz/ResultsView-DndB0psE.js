import{_ as e,c,o as s}from"./index-DU-VOt6M.js";const t={};function n(o,r){return s(),c("h1",null,"Results View")}const a=e(t,[["render",n]]);export{a as default};
